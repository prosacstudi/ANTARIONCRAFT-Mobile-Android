package lol.servidor.antarioncraftmobile

import android.app.Activity
import android.os.Bundle
import android.content.ClipboardManager
import android.content.ClipData
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.widget.*

class MainActivity : Activity() {
    private val host = "va28.holy.gg"
    private val port = 19551 // Geyser config screenshot; external UDP access still needs verification
    private val navy = Color.rgb(5, 13, 31)
    private val cyan = Color.rgb(72, 220, 255)
    private val pale = Color.rgb(226, 244, 255)
    private val muted = Color.rgb(151, 181, 207)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun panel(color: Int, stroke: Int = Color.TRANSPARENT) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(18).toFloat()
        if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke)
    }
    private fun label(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color); gravity = android.view.Gravity.CENTER
        if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }
    private fun params(top: Int = 0, height: Int = -2) = LinearLayout.LayoutParams(-1, height).apply { topMargin = dp(top) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = navy
        window.navigationBarColor = navy
        val scroll = ScrollView(this).apply { setBackgroundColor(navy) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER_HORIZONTAL
            setPadding(dp(22), dp(28), dp(22), dp(24))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(5,14,36), Color.rgb(9,39,72), Color.rgb(4,11,27)))
        }
        val brand = label("✦  ANTARIONCRAFT", 22f, pale, true).apply { letterSpacing = .08f }
        root.addView(brand, params())
        root.addView(label("MÁS ALLÁ DE LAS TIERRAS CONOCIDAS", 10f, cyan, true), params(10))
        val crystal = label("◇", 100f, cyan, true).apply { setShadowLayer(dp(22).toFloat(),0f,0f,Color.BLUE) }
        root.addView(crystal, params(12))
        root.addView(label("EL MUNDO DESCONOCIDO\nTE ESPERA", 24f, pale, true), params())
        root.addView(label("Tu aventura comienza aquí.\nConéctate desde Minecraft Bedrock.", 14f, muted), params(12))
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18),dp(18),dp(18),dp(18))
            background = panel(Color.rgb(13,27,49), Color.rgb(31,81,122))
        }
        card.addView(label("SERVIDOR OFICIAL", 11f, cyan, true), params())
        card.addView(label(host, 20f, pale, true), params(12))
        card.addView(label("PUERTO BEDROCK  •  $port / UDP", 12f, muted, true), params(6))
        card.addView(label("Puerto configurado en Geyser. La conexión desde Internet aún debe verificarse.", 11f, muted), params(12))
        root.addView(card, params(24))
        val join = Button(this).apply {
            text = "ENTRAR A ANTARIONCRAFT  ✦"; textSize = 14f; isAllCaps = false
            setTextColor(Color.rgb(3,20,35)); typeface = Typeface.DEFAULT_BOLD; background = panel(cyan)
            setOnClickListener {
                val launch = packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe")
                if (launch != null) {
                    startActivity(launch)
                    Toast.makeText(this@MainActivity, "Minecraft abierto. Si no aparece el servidor, añádelo manualmente: $host:$port", Toast.LENGTH_LONG).show()
                } else Toast.makeText(this@MainActivity, "No se encontró Minecraft Bedrock instalado.", Toast.LENGTH_LONG).show()
            }
        }
        root.addView(join, params(20, dp(58)))
        val copy = Button(this).apply {
            text = "COPIAR DIRECCIÓN DEL SERVIDOR"; textSize = 12f; isAllCaps = false
            setTextColor(pale); background = panel(Color.rgb(19,40,66), Color.rgb(48,108,151))
            setOnClickListener {
                val cb = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cb.setPrimaryClip(ClipData.newPlainText("ANTARIONCRAFT Bedrock", "$host:$port"))
                Toast.makeText(this@MainActivity, "Copiado: $host:$port", Toast.LENGTH_LONG).show()
            }
        }
        root.addView(copy, params(10, dp(52)))
        root.addView(label("NUEVOS HORIZONTES • ANTARIONCRAFT", 9f, muted), params(26))
        scroll.addView(root); setContentView(scroll)
    }
}
