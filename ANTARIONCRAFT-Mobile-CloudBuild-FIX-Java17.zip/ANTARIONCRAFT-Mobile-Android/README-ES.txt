ANTARIONCRAFT Mobile — versión de interfaz mejorada

Incluye ilustración del explorador/isla flotante dentro de la pantalla, colores cósmicos, botón para abrir Minecraft Bedrock, acceso a Play Store si no está instalado y botón para copiar la dirección.

Servidor mostrado: va28.holy.gg:19551 (UDP). La app no añade automáticamente el servidor dentro de Minecraft; si no aparece, hay que agregarlo manualmente en la lista de servidores.

Para compilar: sube este ZIP al repositorio con el nombre ANTARIONCRAFT-Mobile-CloudBuild-UI-Mejorada.zip y actualiza el workflow para usarlo, o usa sus archivos para reemplazar el proyecto actual. GitHub Actions genera el APK de prueba como artefacto.
