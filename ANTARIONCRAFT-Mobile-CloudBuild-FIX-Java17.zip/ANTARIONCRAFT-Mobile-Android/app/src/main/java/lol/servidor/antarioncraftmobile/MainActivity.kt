package lol.servidor.antarioncraftmobile

import android.app.Activity
import android.os.Bundle
import android.content.ClipboardManager
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val host = "va28.holy.gg"
    private val port = 19551
    private val navy = Color.rgb(5, 13, 31)
    private val cyan = Color.rgb(72, 235, 220)
    private val pale = Color.rgb(235, 248, 255)
    private val muted = Color.rgb(151, 181, 207)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun panel(color: Int, stroke: Int = Color.TRANSPARENT) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(20).toFloat()
        if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke)
    }
    private fun label(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color); gravity = Gravity.CENTER
        if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }
    private fun params(top: Int = 0, height: Int = -2) = LinearLayout.LayoutParams(-1, height).apply { topMargin = dp(top) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(4, 10, 25)
        window.navigationBarColor = Color.rgb(4, 10, 25)
        val scroll = ScrollView(this).apply { setBackgroundColor(navy); isFillViewport = true }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(22), dp(24), dp(22), dp(24))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(4, 10, 28), Color.rgb(7, 34, 69), Color.rgb(3, 8, 22)))
        }
        root.addView(label("✦  ANTARIONCRAFT", 23f, pale, true).apply { letterSpacing = .07f }, params())
        root.addView(label("MÁS ALLÁ DE LAS TIERRAS CONOCIDAS", 10f, cyan, true), params(7))

        // Ilustración principal integrada en la interfaz.
        val heroFrame = FrameLayout(this).apply {
            background = panel(Color.rgb(5, 20, 45), Color.rgb(30, 132, 205))
            clipToOutline = true
        }
        val hero = ImageView(this).apply {
            setImageResource(lol.servidor.antarioncraftmobile.R.drawable.antarion_hero)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            contentDescription = "Explorador de ANTARIONCRAFT sobre una isla flotante de cristales"
        }
        heroFrame.addView(hero, FrameLayout.LayoutParams(-1, -1))
        root.addView(heroFrame, LinearLayout.LayoutParams(-1, dp(255)).apply { topMargin = dp(16) })
        root.addView(label("EL MUNDO DESCONOCIDO\nTE ESPERA", 24f, pale, true), params(14))
        root.addView(label("Tu aventura comienza aquí.\nConéctate desde Minecraft Bedrock.", 14f, muted), params(9))

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(17), dp(18), dp(17))
            background = panel(Color.rgb(8, 22, 43), Color.rgb(28, 101, 153))
        }
        card.addView(label("SERVIDOR OFICIAL", 11f, cyan, true), params())
        card.addView(label(host, 21f, pale, true), params(9))
        card.addView(label("PUERTO BEDROCK  •  $port / UDP", 12f, muted, true), params(5))
        card.addView(label("Servidor para Minecraft Bedrock", 11f, muted), params(8))
        root.addView(card, params(18))

        val join = Button(this).apply {
            text = "ENTRAR A ANTARIONCRAFT  ✦"; textSize = 14f; isAllCaps = false
            setTextColor(Color.rgb(3, 20, 35)); typeface = Typeface.DEFAULT_BOLD; background = panel(cyan)
            setOnClickListener {
                val launch = packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe")
                if (launch != null) {
                    startActivity(launch)
                    Toast.makeText(this@MainActivity, "Minecraft abierto. Añade el servidor si aún no aparece: $host:$port", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this@MainActivity, "Minecraft Bedrock no está instalado. Instálalo y vuelve a intentarlo.", Toast.LENGTH_LONG).show()
                    try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.mojang.minecraftpe"))) }
                    catch (_: Exception) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.mojang.minecraftpe"))) }
                }
            }
        }
        root.addView(join, params(17, dp(56)))
        val copy = Button(this).apply {
            text = "COPIAR DIRECCIÓN DEL SERVIDOR"; textSize = 12f; isAllCaps = false
            setTextColor(pale); background = panel(Color.rgb(12, 31, 56), Color.rgb(48, 108, 151))
            setOnClickListener {
                val cb = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cb.setPrimaryClip(ClipData.newPlainText("ANTARIONCRAFT Bedrock", "$host:$port"))
                Toast.makeText(this@MainActivity, "Copiado: $host:$port", Toast.LENGTH_LONG).show()
            }
        }
        root.addView(copy, params(9, dp(51)))
        root.addView(label("NUEVOS HORIZONTES  •  ANTARIONCRAFT", 9f, muted), params(20))
        scroll.addView(root); setContentView(scroll)
    }
}
